#include <iostream>
#include "tools.h"

using Eigen::VectorXd;
using Eigen::MatrixXd;
using std::vector;

Tools::Tools() {}

Tools::~Tools() {}

VectorXd Tools::CalculateRMSE(const vector<VectorXd> &estimations,
                              const vector<VectorXd> &ground_truth) {
  /**
  TODO:
    * Calculate the RMSE here.
  */

 VectorXd rmse = VectorXd(4);
 rmse << 0,0,0,0;// Initialize error to zero

 if((estimations.size()!=ground_truth.size())||(estimations.size()==0))
 {
  cout<<"Invalid Estimation or Ground Truth data"<<endl;
  return rmse;  
 }   

 // Calculation of RMSE
 for(unsigned int i=0; i<estimations.size();i++)
 {
  VectorXd residual = estimations[i] - ground_truth[i];

  residual = residual.array()*residual.array();
  rmse=rmse+residual;
 } 

rmse = rmse/estimations.size(); // Mean of RMSE
rmse = rmse.array().sqrt(); // Calculate square root of an array

return rmse;
}
