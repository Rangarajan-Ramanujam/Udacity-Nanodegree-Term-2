#include <iostream>
#include "tools.h"

using Eigen::VectorXd;
using Eigen::MatrixXd;
using std::vector;

Tools::Tools() {}

Tools::~Tools() {}

VectorXd Tools::CalculateRMSE(const vector<VectorXd> &estimations,
                              const vector<VectorXd> &ground_truth) {
  /**
  TODO:
    * Calculate the RMSE here.
  */

  VectorXd rmse(4);
  //Initialize with 0 values
  rmse.fill(0.0);

  // Check for validity of the inputs
  if(estimations.size() != ground_truth.size() || estimations.size()==0)
   {
	cout<<"Invalid Estimation or Ground Truth Data"<<endl;
        return rmse;

   }

  // Compute the RMSE
   for(unsigned int i=0;i<estimations.size();i++)
   {
	VectorXd residual = estimations[i]- ground_truth[i];
        residual = residual.array()*residual.array();
	rmse=rmse+=residual;
   }

   //Calculate Mean and sqare root
   rmse = rmse/estimations.size();
   rmse = rmse.array().sqrt();

   return rmse;
}

MatrixXd Tools::CalculateJacobian(const VectorXd &x_state) {
  /**
  TODO:
    * Calculate a Jacobian here.
  */
  MatrixXd H_ekf = MatrixXd(3,4);
  H_ekf.fill(0.0f);

  // Update first 2 rows
  float px=x_state[0];
  float py=x_state[1];
  float vx=x_state[2];
  float vy=x_state[3];

  if(fabs(px)<=0.0001f && fabs(py)<=0.0001f)
  {
   return H_ekf; 
  }

  float rho=sqrt(px*px+py*py);
  float rho2=px*px + py*py;
  float rho3=rho2*rho;
  H_ekf << (px/rho),(py/rho),0,0,
           (-py/rho2),(px/rho2),0,0,
          py*(vx*py-vy*px)/rho3,px*(px*vy-py*vx)/rho3,px/rho,py/rho;

  return H_ekf;

}
